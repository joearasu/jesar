﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jesarairline
{
    public partial class SiteMaster : MasterPage
    {
        protected Admin_User _usr = new Admin_User();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["jesarAdmin"] == null)
            {
                Response.Redirect("~/index.aspx", true);
            }

            if (Session["jesarAdmin"] != null)
            {
                _usr = (Admin_User)Session["jesarAdmin"];
               
            }
        }
    }
}