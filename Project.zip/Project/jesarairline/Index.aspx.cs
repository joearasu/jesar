﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jesarairline
{
    public partial class Index : System.Web.UI.Page
    {
        private DbInterface db = new DbInterface();
        protected Admin_User User = new Admin_User();
        //FWClass fwClass = new FWClass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Session["PAGE_LOAD"] = null;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "LAW", "javascript:ClearLoginFields();", true);
            }

        }

        public bool ValidateUser(string _usr, string _pwd)
        {

            MySqlDataReader dr = null;
            bool flag = false;
            string sql = "";

            try
            {
                sql = "SELECT  fld_id," +
                    " fld_username," +
                    " fld_password FROM tbl_admin " +
                    " WHERE fld_username= @usr " +
                    " AND fld_password = @pwd " +
                    " AND fld_status = '1'";
                MySqlCommand cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@usr", _usr);
                cmd.Parameters.AddWithValue("@pwd", _pwd);
                dr = db.Read(cmd);

                if (dr.Read())
                {
                    flag = true;
                    User.UserId = dr.GetString(0);
                    User.Username = dr.GetString(1);
                    User.Password = dr.GetString(2);
                }
                dr.Close();

                if (flag == true)
                {
                    System.Web.HttpContext.Current.Session["jesarAdmin"] = User;
                    //System.Web.HttpContext.Current.Session.Timeout = 10000;
                    System.Web.Security.FormsAuthentication.SetAuthCookie(User.UserId, false);
                    //fwClass.saveLogin(User.UserId, Request.UserHostAddress);
                }
            }
            finally
            {
                db.Close();
            }
            return flag;
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {

            if (txt_User.Text != "" && txt_Password.Text != "")
            {
                string usr = txt_User.Text;
                string pwd = txt_Password.Text;

                Session["jesarAdmin"] = null;

                if (ValidateUser(usr, pwd) == true)
                {
                    Response.Cookies["jesarAdmin"].Value = usr;
                    Response.Cookies["jesarAdmin"].Value = pwd;
                    Response.Redirect("About.aspx");
                }

                else
                {
                    string msg = "Invalid Login";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                    txt_Password.Attributes.Add("value", "********");
                }
            }
            else
            {
                string msg = "Please enter valid data";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "BQW", "javascript:InfoPopup('','" + msg + "','1');", true);
                txt_Password.Attributes.Add("value", "********");
            }

        }
    }
}