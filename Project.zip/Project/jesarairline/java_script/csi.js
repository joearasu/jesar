﻿
function isNumeric(evt, obj) {
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if (charCode == 45) {
        if (obj.value.indexOf('-') == -1) {
            return true;
        }
        else {
            return false;
        }
    }
    else if ((charCode > 31 && (charCode < 46 || charCode > 57))) {
        return false;
    }
    else if ((charCode > 95) && (charCode < 105)) {
        return false;
    }
    else if ((charCode > 106) && (charCode < 109)) {
        return false;
    }
    else if (charCode == 47) {
        return false;
    }
    else {
        if (charCode == 46) {
            if (obj.value.indexOf('.') == -1) {
                obj.title = obj.value;
                return true;
            }
            else {
                return false;
            }
        }
        obj.title = obj.value;
        return true;
    }
}



function isNumber(event, obj) {
   
    var key = window.event ? event.keyCode : event.which;
    //alert(key);
    if (event.keyCode === 8 ) {

        return true;
    }
    else if (key < 48 || key > 57)
    {
        return false;
    }
    else if (key == 46) //decimal
    {
        return false;
    }
    else {
        return true;
    }
}
