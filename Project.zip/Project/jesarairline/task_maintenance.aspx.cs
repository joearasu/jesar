﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jesarairline
{

    
    public partial class WebForm1 : System.Web.UI.Page
    {
        private DbInterface db = new DbInterface();
        private DbInterface db1 = new DbInterface();
        private DbInterface db2 = new DbInterface();
        protected Admin_User Usr = new Admin_User();
        FWClass fwClass = new FWClass();
        Admin_User _Usr = new Admin_User();
        string sql = string.Empty;
        string sql1 = string.Empty;
        string sql2 = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySql.Data.MySqlClient.MySqlCommand cmd1 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd2 = null;
        MySqlDataReader dr = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["jesarAdmin"] != null)
            {
                _Usr = (Admin_User)Session["jesarAdmin"];
                FillRegistrationNumber();
                FillGrid();
                FillEngineer();
            }

           
        }

        private void FillRegistrationNumber()
        {
            try
            {
                ddl_regno.Items.Clear();
                ListItem item = new ListItem();
                item = new ListItem("-- PLEASE SELECT A REG# --", "0");
                ddl_regno.Items.Add(item);
                sql = "SELECT fld_id , " +
                    " fld_regno " +
                    " FROM table_flginfo WHERE fld_status ='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item = new ListItem(dr["fld_regno"].ToString(), dr["fld_id"].ToString());
                    ddl_regno.Items.Add(item);

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void FillEngineer()
        {
            try
            {
                ddl_engineer.Items.Clear();
                ListItem item = new ListItem();
                item = new ListItem("-- PLEASE SELECT A ENGINEER --", "0");
                ddl_engineer.Items.Add(item);
                sql = "SELECT fld_id , " +
                    " CONCAT(fld_Engineer,' -- ',fld_engineer_task) as engineer" +
                    " FROM table_engineer WHERE fld_status ='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item = new ListItem(dr["engineer"].ToString(), dr["fld_id"].ToString());
                    ddl_engineer.Items.Add(item);

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        protected void btn_add_task(object sender, EventArgs e)
        {
            try
            {
                string tt = string.Empty;
                tt = hid_task_reg.Value;
                string ttid = string.Empty;
                ttid = hid_task_reg_id.Value;
                string eng_id = string.Empty;
                eng_id = hid_engineer_id.Value;
                string eng_name = string.Empty;
                eng_name = hid_engineer_name.Value;

                sql = "INSERT INTO table_taskmain(" +
                   "fld_ttype," +
                   "fld_tdes," +
                   "fld_tpart," +
                   "fld_tpartsno," +
                   "fld_regno," +
                   "fld_engineer," +
                   "fld_status ) VALUES(" +
                   "@fld_ttype," +
                   "@fld_tdes," +
                   "@fld_tpart," +
                   "@fld_tpartsno," +
                   "@fld_regno," +
                   "@fld_engineer," +
                   "1);";
                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@fld_ttype", ddl_task_type.SelectedValue);
                cmd.Parameters.AddWithValue("@fld_tdes", txt_des.Text);
                cmd.Parameters.AddWithValue("@fld_tpart", txt_part.Text);
                cmd.Parameters.AddWithValue("@fld_tpartsno", txt_partsno.Text);
                cmd.Parameters.AddWithValue("@fld_regno", tt);
                cmd.Parameters.AddWithValue("@fld_engineer", eng_name);
                db.Execute(cmd);

                sql1 = "Update table_flginfo set fld_status = @status where fld_id = @id";
                cmd1 = new MySqlCommand(sql1);
                cmd1.Parameters.AddWithValue("@status", '2');
                cmd1.Parameters.AddWithValue("@id", ttid);
                db1.Execute(cmd1);

                sql2 = "Update table_engineer set fld_status = @status where fld_id = @id";
                cmd2 = new MySqlCommand(sql2);
                cmd2.Parameters.AddWithValue("@status", '2');
                cmd2.Parameters.AddWithValue("@id", eng_id);
                db2.Execute(cmd2);

            }
            finally
            {
                db.Close();
                db1.Close();
                db2.Close();
                Response.Redirect("task_maintenance.aspx");
            }
        }

        private void FillGrid()
        {
            StringBuilder sb = new StringBuilder();
            try
            {

                // sql = "SELECT j.fld_id," +
                //"j.fld_regno," +
                //"j.fld_ttype," +
                //"case j.fld_ttype when '1' then 'Service' when '2' then 'Repair'  end as task," +
                //"j.fld_tdes," +
                //"j.fld_tpart," +
                //"j.fld_tpartsno " +
                //"FROM table_flginfo i left inner join table_taskmain j where i.fld_regno =j.fld_regno and i.fld_status = 2 ";

                sql = "SELECT fld_id," +
               "fld_regno," +
               "case fld_ttype when '1' then 'Service' when '2' then 'Repair'  end as fld_ttype," +
               "fld_tdes," +
               "fld_tpart," +
               "fld_tpartsno, " +
               "fld_engineer " +
               "FROM table_taskmain where fld_status='1'";


                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblTask\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>Reg#</th>" +
                    "<th>Task Type</th>" +
                    "<th>Task Description</th>" +
                    "<th>Part</th>" +
                    "<th>Part Serial Number</th>" +
                    "<th>Engineer</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_regno"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_ttype"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_tdes"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_tpart"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_tpartsno"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_engineer"].ToString() + "</td>" +
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" class=\"text-warning\">No sceduled record found under task maintenance</h3>");
                }

                lbl_grid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }

        private void FillEngineer(string task)
        {
            try
            {
                ddl_engineer.Items.Clear();
                ListItem item = new ListItem();
                item = new ListItem("-- PLEASE SELECT A ENGINEER --", "0");
                ddl_engineer.Items.Add(item);
                sql = "SELECT fld_id , " +
                    " CONCAT(fld_Engineer,' -- ',fld_engineer_task) as engineer" +
                    " FROM table_engineer WHERE fld_status ='1' AND fld_engineer_task='"+task+"'  ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item = new ListItem(dr["engineer"].ToString(), dr["fld_id"].ToString());
                    ddl_engineer.Items.Add(item);

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        protected void ddl_task_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            string taskid = string.Empty;
            string task = string.Empty;
            try 
            {
                taskid = ddl_task_type.SelectedValue;
                if (taskid == "1")
                {
                    task = "Service";
                }
                if (taskid == "2")
                {
                    task = "Repair";
                }
                FillEngineer(task);
            }
            finally 
            {
                task = "";
            }
        }
    }
    }
