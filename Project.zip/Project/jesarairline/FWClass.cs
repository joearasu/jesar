﻿using MySql.Data.MySqlClient;
using System;
using System.Configuration;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;

public class FWClass
{
    string sql = string.Empty;
    private DbInterface db = new DbInterface();   
    MySqlDataReader dr = null;

    #region LOGOUT
    public void Logout()
    {        
        HttpContext.Current.Session.Abandon();
        HttpContext.Current.Session.RemoveAll();
        System.Web.Security.FormsAuthentication.SignOut();
        HttpContext.Current.Response.Redirect("~/login.aspx", true);
    }    
    #endregion

    
    public void saveLogin(string _userid, string _ip)
    {
        try
        {
            string query = "INSERT INTO tbl_logins " +
                "(fld_userid,fld_ipaddress,fld_datetime,fld_isadmin" +
                ") " +
                "VALUES (" + _userid + ",'" + _ip + "',now(),1" +
                ");";

            MySqlCommand cmd = new MySqlCommand(query);
            db.Execute(cmd);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            db.Close();
        }
    }

    public string getFileList(string folderName)
    {
        string filepath = "";
        string fullpath = "";
        bool flag = false;
        StringBuilder sb = new StringBuilder();

        sb.Append("<table id=\"tblstudent\" class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\"><thead><tr><th style=\"display:none;\">Id<th>Name</th><th>URL</th><th width='100'>Actions</th></tr></thead><tbody>");
        filepath = ConfigurationManager.AppSettings["FilePathRoot"].ToString();
        filepath = filepath + folderName;

        DirectoryInfo di = new DirectoryInfo(filepath);

        if (di != null)
        {
            //FileInfo[] subFiles = di.GetFiles();
            FileInfo[] subFiles = di.GetFiles("*.*", SearchOption.TopDirectoryOnly);

            foreach (FileInfo subFile in subFiles)
            {
                if (!subFile.Name.Contains("FileNotFound"))
                {

                    flag = true;
                    fullpath = ConfigurationManager.AppSettings["str_URL"].ToString() + folderName + "/" + subFile.Name;
                    sb.Append("<tr>" +
                        //"<td><a href=" + dr["Pages"].ToString() + ".aspx?id=" + dr["id"].ToString() + "&type=" + dr["fld_pagetypeid"].ToString() + " target=\"_self\">" + dr["fld_name"].ToString() + "</td>" +
                   "<td   style=\"display:none;\"></td>" +

                   "<td width=\"160px\"><a href='" + fullpath + "'  target=\"_blank\">" + subFile.Name + "</td>" +
                   "<td width=\"350px\">" + fullpath + "</td>");
                    
                    //sb.Append("<td><img title=\"Copy\" src=\"img/copy.png\" border=\"0\" style=\"cursor:pointer\" onclick=\"CopyToClipboard('" + fullpath + "')\">");

                    //insertLink('<a href=\'http://google.com\'>google.com</a>')

                    sb.Append("<td><img title=\"Copy\" src=\"img/copy.png\" border=\"0\" style=\"cursor:pointer\" onclick=\"setLink('<a href=" + fullpath + ">" + subFile.Name + "</a>');\">");

                    sb.Append("<img title=\"Delete\" src=\"img/delete_icon.png\" border=\"0\" style=\"cursor:pointer\" onclick=\"DeleteFiles('" + folderName + "/" + subFile.Name + "')\"></td>");
                    sb.Append("</tr>");

                }

            }
        }

        if (flag)
        {
            sb.Append("</tbody></table>");
        }
        else
        {          
            sb.Append("<tr><td colspan='4' align='left'><font color='red'>No files in this folder!</font></td></tr></tbody></table>");
        }

        return sb.ToString();
    }
    public void loadLanguages(DropDownList ddl,
           bool isSelectItemNeeded)
    {
        MySqlDataReader dr = null;

        try
        {
            ddl.Items.Clear();

            ListItem item;

            if (isSelectItemNeeded)
            {
                item = new ListItem("-- SELECT --", "0");
                ddl.Items.Add(item);
            }

            string query = "SELECT fld_id,fld_language FROM tbl_languages WHERE fld_status=1 ORDER BY fld_default desc;";// ORDER BY fld_title";

            MySqlCommand cmd = new MySqlCommand(query);

            dr = db.Read(cmd);

            while (dr.Read())
            {
                item = new ListItem(dr["fld_language"].ToString(), dr["fld_id"].ToString());
                ddl.Items.Add(item);
            }
            dr.Close();
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            if (!dr.IsClosed)
            {
                dr.Close();
            }
            db.Close();
        }
    }
}

   
