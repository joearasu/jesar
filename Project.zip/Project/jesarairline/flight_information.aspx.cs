﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jesarairline
{
    public partial class flight_information : System.Web.UI.Page
    {
        private DbInterface db = new DbInterface();
        private DbInterface db1 = new DbInterface();
        private DbInterface db2 = new DbInterface();
        protected Admin_User Usr = new Admin_User();
        FWClass fwClass = new FWClass();
        Admin_User _Usr = new Admin_User();
        string sql = string.Empty;
        string sql1 = string.Empty;
        string sql2 = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySql.Data.MySqlClient.MySqlCommand cmd1 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd2 = null;
        MySqlDataReader dr = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["jesarAdmin"] != null)
            {
                _Usr = (Admin_User)Session["jesarAdmin"];
                FillGrid();
            }

        }

        private void FillGrid()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sql = "SELECT fld_id," +
                  "fld_regno," +
                  "fld_sno," +
                  "fld_model," +
                  //"fld_owner," +
                  //"fld_location," +
                  "fld_hour " +
                  "FROM table_flginfo ";
                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblFlightInfo\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>Reg#</th>" +
                    "<th>Serial#</th>" +
                    "<th>Model</th>" +
                    //"<th>Owner</th>" +
                    //"<th>Base Location</th>" +
                    "<th>Hours in Air</th>" +
                   "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_regno"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_sno"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_model"].ToString() + "</td>" +
                    //"<td style=\"padding-left:8px;\">" + dr["fld_owner"].ToString() + "</td>" +
                    //"<td style=\"padding-left:8px;\">" + dr["fld_location"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_hour"].ToString() + "</td>" +
                     "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" class=\"text-warning\">No sceduled record found under flight information</h3>");
                }

                lbl_grid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }

        protected void btn_add_flight_information(object sender, EventArgs e)
        {
            string regno = string.Empty;
            bool isexist = false;

            regno = txt_regno.Text;
            sql = "select fld_regno from table_flginfo where fld_status ='1' and fld_regno='" + regno + "'";
            cmd = new MySqlCommand(sql);
            dr = db.Read(cmd);
            if (dr.Read())
            {
                isexist = true;
                RegAleadyExist();
            }
            dr.Close();


            if (isexist == false)
            {
                try
                {

                    sql = "INSERT INTO table_flginfo(" +
                       "fld_regno," +
                       "fld_sno," +
                       "fld_model," +
                       //"fld_owner," +
                       //"fld_location," +
                       "fld_hour," +
                        "fld_status) VALUES(" +
                       "@fld_regno," +
                       "@fld_sno," +
                       "@fld_model," +
                       //"@fld_owner," +
                       //"@fld_location," +
                       "@fld_hour," +
                       "1);";
                    cmd = new MySqlCommand(sql);
                    cmd.Parameters.AddWithValue("@fld_regno", txt_regno.Text);
                    cmd.Parameters.AddWithValue("@fld_sno", txt_serialno.Text);
                    cmd.Parameters.AddWithValue("@fld_model", txt_model.Text);
                    //cmd.Parameters.AddWithValue("@fld_owner", txt_add_owner.Text);
                    //cmd.Parameters.AddWithValue("@fld_location", txt_location.Text);
                    cmd.Parameters.AddWithValue("@fld_hour", txt_hour.Text);
                    db.Execute(cmd);

                }
                finally
                {
                    db.Close();
                    Response.Redirect("flight_information.aspx");
                }
            }

        }

        private void RegAleadyExist()
        {
            string script = "RegAleadyExist();";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "keySend1", script, true);
        }

    }
}