﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jesarairline
{
    public partial class list_of_engineer : System.Web.UI.Page
    {

        private DbInterface db = new DbInterface();
        private DbInterface db1 = new DbInterface();
        private DbInterface db2 = new DbInterface();
        protected Admin_User Usr = new Admin_User();
        FWClass fwClass = new FWClass();
        Admin_User _Usr = new Admin_User();
        string sql = string.Empty;
        string sql1 = string.Empty;
        string sql2 = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySql.Data.MySqlClient.MySqlCommand cmd1 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd2 = null;
        MySqlDataReader dr = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["jesarAdmin"] != null)
            {
                _Usr = (Admin_User)Session["jesarAdmin"];
                FillGrid();
            }

            
        }

        private void FillGrid()
        {
            StringBuilder sb = new StringBuilder();
            try
            {

                sql = "SELECT fld_id," +
               " fld_engineer," +
               " fld_engineer_task," +
               " case fld_status when '1' then 'Available' when '2' then 'Already Assigned'  end as fld_status " +
               " FROM table_engineer ";
                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblEngineer\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>Engineer</th>" +
                    "<th>Task</th>" +
                    "<th>Status</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_engineer"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_engineer_task"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_status"].ToString() + "</td>" +
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" class=\"text-warning\">No record found</h3>");
                }

                lbl_grid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }
    }
}